var express = require('express');
var mysql = require('./dbcon.js');

var app = express();
var handlebars = require('express-handlebars').create({defaultLayout:'main'});
var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.engine('handlebars', handlebars.engine);
app.set('view engine', 'handlebars');
app.set('port', 7754); //Site address: http://flip3.engr.oregonstate.edu/7754
app.use(express.static('public')); //Allows files from the public folder to be accessed

app.get('/',function(req,res,next){
    res.render('home');
});

// Does get request and sends the database entries to home_ajax where keywords match either the product title or description.
app.get('/search', function(req, res, next){
  var context = {};
  mysql.pool.query('SELECT * FROM Products WHERE name REGEXP ? OR description REGEXP ?', [req.query.name, req.query.name], function(err, rows, fields){
    if(err){
      next(err);
      return;
    }
    context.results = rows
    res.send(context);
  });
});

//Go to http://flip3.engr.oregonstate.edu/7754/vendors to see vendors.handlebars
app.get('/vendors',function(req,res,next){
      res.render('vendors');
});

app.get('/products_table',function(req,res,next){
  var context = {};
  mysql.pool.query("INSERT INTO Products( `price`, `stock`, `description`, `image`, `cart`) VALUES (?,?,?,?,?,?)", 
  [req.query.name, req.query.price, req.query.stock, req.query.description, req.query.image, req.query.cart], function(err, result){
    if(err){
      next(err);
      return;
    }
    context.insert = req.query
    context.results = result
    res.send(context)
  });
});

app.get('/vendors_insert',function(req,res,next){
  var context = {};
  mysql.pool.query("INSERT INTO Vendors( `company`, `email`, `phone`) VALUES (?,?,?)", 
  [req.query.company, req.query.email, req.query.phone], function(err, result){
    if(err){
      next(err);
      return;
    }
    context.insert = req.query
    context.results = result
    res.send(context)
  });
});

//Go to http://flip3.engr.oregonstate.edu/7754/product?id=x to see the product page for product with id x
//Click on a product search result automatically links to this page
app.get('/product',function(req,res,next){
  var context = {};
  mysql.pool.query('SELECT * FROM products WHERE id=?', [req.query.id], function(err, rows, fields){
    if(err){
      next(err);
      return;
    }
    context.results = rows
  res.render('product', context);
  });
});

app.use(function(req,res){
  res.status(404);
  res.render('404');
});

app.use(function(err, req, res, next){
  console.error(err.stack);
  res.status(500);
  res.render('500');
});

app.listen(app.get('port'), function(){
  console.log('Express started on http://flip3.engr.oregonstate.edu/' + app.get('port') + '; press Ctrl-C to terminate.');
});
