Steps to run 
1. SSH into bash
2. Navigate to WorldRecords directory
3. Run command "npm install" to get node_modules folder
4. Run command "node WR-Server-Side.js" to host on http://flip3.engr.oregonstate.edu:7754/